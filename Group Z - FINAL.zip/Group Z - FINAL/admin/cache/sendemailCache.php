<?php
 return array (
  '_pk' => 'id',
  '_auto' => 'id',
  0 => 'id',
  1 => 'enter_id',
  2 => 'email',
  3 => 'content',
  4 => 'addtime',
)
?>