<?php
 return array (
  '_pk' => 'id',
  '_auto' => 'id',
  0 => 'id',
  1 => 'enter_id',
  2 => 'user_id',
  3 => 'activity_id',
  4 => 'content',
  5 => 'score',
  6 => 'addtime',
)
?>