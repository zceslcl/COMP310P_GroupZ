<?php
 return array (
  '_pk' => 'id',
  '_auto' => 'id',
  0 => 'id',
  1 => 'user_id',
  2 => 'type_id',
  3 => 'assess_id',
  4 => 'name',
  5 => 'title',
  6 => 'activity_pic',
  7 => 'descr',
  8 => 'start_time',
  9 => 'end_time',
  10 => 'location',
  11 => 'over',
  12 => 'remark',
  13 => 'price',
  14 => 'status',
  15 => 'sale_time',
  16 => 'create_time',
)
?>