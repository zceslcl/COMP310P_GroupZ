<?php
 return array (
  '_pk' => 'id',
  '_auto' => 'id',
  0 => 'id',
  1 => 'username',
  2 => 'realname',
  3 => 'password',
  4 => 'sex',
  5 => 'user_email',
  6 => 'user_phone',

)
?>