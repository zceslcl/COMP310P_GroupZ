<?php
 return array (
  '_pk' => 'id',
  '_auto' => 'id',
  0 => 'id',
  1 => 'user_id',
  2 => 'activity_id',
  3 => 'type_id',
  4 => 'create_time',
  5 => 'username',
  6 => 'user_phone',
  7 => 'activity_name',
  8 => 'activity_address',
  9 => 'bank',
  10 => 'number',
  11 => 'code',
  12 => 'status',
  13 => 'user_email',
)
?>