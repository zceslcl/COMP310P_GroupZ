<?php
 return array (
  '_pk' => 'id',
  '_auto' => 'id',
  0 => 'id',
  1 => 'name',
  2 => 'pid',
  3 => 'path',
)
?>