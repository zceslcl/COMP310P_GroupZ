<?php
	/*
			$this->host = DB_HOST;
			$this->user = DB_USER;
			$this->pwd = DB_PWD;
			$this->charset = DB_CHARSET;
			$this->prefix = DB_PREFIX;
			$this->dbname = DB_NAME;

	 */

	define('DB_HOST','localhost');
	define('DB_USER','root');
	define('DB_PWD','root');
	define('DB_CHARSET','utf8');
	define('DB_PREFIX','');
	define('DB_NAME','activity');
	date_default_timezone_set('PRC');